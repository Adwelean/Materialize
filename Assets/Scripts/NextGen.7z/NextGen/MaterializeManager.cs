﻿using System;
using System.IO;

using Assets.Scripts.NextGen.GeneratorDescriptor;

using Cysharp.Threading.Tasks;
using Cysharp.Threading.Tasks.Linq;

using UnityEngine;

using HeightMap = Assets.Scripts.NextGen.GeneratorDescriptor.HeightMapDescriptor;
using NormalMap = Assets.Scripts.NextGen.GeneratorDescriptor.NormalMapDescriptor;
using MetalicMap = Assets.Scripts.NextGen.GeneratorDescriptor.MetalicMapDescriptor;
using SmoothnessMap = Assets.Scripts.NextGen.GeneratorDescriptor.SmoothnessMapDescriptor;
using EdgeMap = Assets.Scripts.NextGen.GeneratorDescriptor.EdgeMapDescriptor;
using AOMap = Assets.Scripts.NextGen.GeneratorDescriptor.AOMapDescriptor;

namespace Assets.Scripts.NextGen
{
    public class MaterializeManager
    {
        public MaterializeManager()
        {
        }

        public async UniTask<bool> Generate(IUniTaskAsyncEnumerable<string> textureFilesPaths, MaterializeSettings materializeSettings = default)
        {
            bool ret = true;

            await textureFilesPaths.ForEachAwaitAsync(async textureFilePath =>
            {
                try
                {
                    await Generate(textureFilePath, materializeSettings ?? MaterializeSettings.Default);
                }
                catch (Exception ex)
                {
                    ret = false;
                }
            });

            return ret;
        }

        public async UniTask<bool> Generate(string textureFilePath, MaterializeSettings materializeSettings = default)
        {
            if (materializeSettings == default)
                materializeSettings = MaterializeSettings.Default;

            var diffuseTextureFileInfo = new FileInfo(textureFilePath);
            var diffuseTextureFileName = diffuseTextureFileInfo.Name.Replace(diffuseTextureFileInfo.Extension, "");
            var diffuseTextureFileRawData = File.ReadAllBytes(textureFilePath);
            var diffuseMap = new Texture2D(2, 2);

            if (!diffuseMap.LoadImage(diffuseTextureFileRawData))
            {
                Debug.LogError($"Cannot load texture data. ({diffuseTextureFileInfo.FullName})");
                return false;
            }

            var heightMap = await Generate<HeightMap>(diffuseMap, default, default, diffuseTextureFileInfo.DirectoryName, diffuseTextureFileName, materializeSettings);
            var normalMap = await Generate<NormalMap>(diffuseMap, heightMap.MapResult, default, diffuseTextureFileInfo.DirectoryName, diffuseTextureFileName, materializeSettings);
            var metalicMap = await Generate<MetalicMap>(diffuseMap, default, default, diffuseTextureFileInfo.DirectoryName, diffuseTextureFileName, materializeSettings);
            var smoothnessMap = await Generate<SmoothnessMap>(diffuseMap, metalicMap.MapResult, default, diffuseTextureFileInfo.DirectoryName, diffuseTextureFileName, materializeSettings);
            var edgeMap = await Generate<EdgeMap>(diffuseMap, normalMap.MapResult, default, diffuseTextureFileInfo.DirectoryName, diffuseTextureFileName, materializeSettings);
            var aoMap = await Generate<AOMap>(diffuseMap, normalMap.MapResult, heightMap.AlternativeMapResult, diffuseTextureFileInfo.DirectoryName, diffuseTextureFileName, materializeSettings);

            return await UniTask.FromResult(true);
        }

        private async UniTask<(Texture2D MapResult, Texture AlternativeMapResult)> Generate<T>(Texture2D diffuseMap, Texture2D map1, Texture map2, string directory, string diffuseMapFileName, MaterializeSettings materializeSettings)
            where T : IGeneratorDescriptor
        {
            Texture2D textureMap = default;
            Texture alternativeMap = default;
            IGeneratorDescriptor descriptor = Activator.CreateInstance<T>();

            try
            {
                var processor = descriptor.GetProcessor(materializeSettings);

                (textureMap, alternativeMap) = await processor.Process(diffuseMap, map1, map2);

                File.WriteAllBytes(Path.Combine(directory, descriptor.GetFileName(diffuseMapFileName)), textureMap.EncodeToPNG());
            }
            catch (Exception)
            {
                Debug.LogError($"Failed to generate {descriptor.GetName()} for file {diffuseMapFileName}");
                throw;
            }

            return (textureMap, alternativeMap);
        }
    }
}
