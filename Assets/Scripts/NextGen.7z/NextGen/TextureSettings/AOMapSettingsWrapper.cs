﻿namespace Assets.Scripts.NextGen.TextureSettings
{
    public class AOMapSettingsWrapper : AoSettings, ITextureSettings
    {
        public AOMapSettingsWrapper()
        {
        }
    }
}
