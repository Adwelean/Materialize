﻿namespace Assets.Scripts.NextGen.TextureSettings
{
    public interface ITextureSettings
    {
    }
}
