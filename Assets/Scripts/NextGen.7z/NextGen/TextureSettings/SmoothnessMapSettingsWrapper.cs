﻿namespace Assets.Scripts.NextGen.TextureSettings
{
    public class SmoothnessMapSettingsWrapper : SmoothnessSettings, ITextureSettings
    {
    }
}
