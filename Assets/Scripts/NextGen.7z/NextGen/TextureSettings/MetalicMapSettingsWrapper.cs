﻿namespace Assets.Scripts.NextGen.TextureSettings
{
    public class MetalicMapSettingsWrapper : MetallicSettings, ITextureSettings
    {
    }
}
