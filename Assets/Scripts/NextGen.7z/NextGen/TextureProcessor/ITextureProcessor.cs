﻿
using Cysharp.Threading.Tasks;

using UnityEngine;

namespace Assets.Scripts.NextGen.TextureProcessor
{
    public interface ITextureProcessor
    {
        UniTask<(Texture2D MapResult, Texture AlternativeMapResult)> Process(Texture2D diffuseMap, Texture2D texture1 = default, Texture texture2 = default);
    }
}
