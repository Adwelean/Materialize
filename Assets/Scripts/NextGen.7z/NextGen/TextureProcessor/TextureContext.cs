﻿using System.Collections.Generic;

using UnityEngine;

namespace Assets.Scripts.NextGen.TextureProcessor
{
    public enum TypeMap
    {
        Diffuse,
        Height,
        HeightHD,
        Normal,
        Metalic,
        Smoothness,
        Edge,
        AO
    }

    public enum ProcessorPhase
    {
        None,
        HeightMapProcessed,
        NormalMapProcessed,
        MetalicMapProcessed,
        SmoothnessMapProcessed,
        EdgeMapProcessed,
        AOMapProcessed
    }

    public class TextureContext
    {
        public ProcessorPhase ProcessorPhase { get; set; } = ProcessorPhase.None;

        public Dictionary<TypeMap, Texture> Textures { get; set; } = new Dictionary<TypeMap, Texture>();
    }
}
