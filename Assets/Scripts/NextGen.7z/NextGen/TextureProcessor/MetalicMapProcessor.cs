﻿using Assets.Scripts.NextGen.ShaderWrapper;
using Assets.Scripts.NextGen.TextureSettings;

using Cysharp.Threading.Tasks;

using UnityEngine;

namespace Assets.Scripts.NextGen.TextureProcessor
{
    public class MetalicMapProcessor : TextureProcessorBase<MetalicMapSettingsWrapper>
    {
        public MetalicMapProcessor(MetalicMapSettingsWrapper textureSettings)
            : base(textureSettings)
        {
        }

        private RenderTexture CreateRenderTexture(int width, int height, int depth = 0, RenderTextureFormat renderTextureFormat = RenderTextureFormat.ARGB32)
            => new RenderTexture(width, height, depth, renderTextureFormat, RenderTextureReadWrite.Linear) { wrapMode = TextureWrapMode.Repeat };

        public override UniTask<(Texture2D MapResult, Texture AlternativeMapResult)> Process(Texture2D diffuseMap, Texture2D _, Texture __)
        {
            var blitShader = new BlitShaderWrapper();

            var imageSizeX = diffuseMap.width;
            var imageSizeY = diffuseMap.height;

            var tempMap = CreateRenderTexture(imageSizeX, imageSizeY);
            var blurMap = CreateRenderTexture(imageSizeX, imageSizeY);
            var overlayBlurMap = CreateRenderTexture(imageSizeX, imageSizeY);

            ApplyBlurMapFromDiffuseMapToBlitMaterial(ref blitShader, diffuseMap, imageSizeX, imageSizeY, tempMap, blurMap, overlayBlurMap);

            tempMap.Release();
            tempMap = CreateRenderTexture(imageSizeX, imageSizeY);

            var metalicMap = CreateMetalicMap(diffuseMap, tempMap, blurMap, overlayBlurMap);

            return UniTask.FromResult((metalicMap, default(Texture)));
        }

        public void ApplyBlurMapFromDiffuseMapToBlitMaterial(ref BlitShaderWrapper blitShader, in Texture2D diffuseTexture, in int imageSizeX, in int imageSizeY, RenderTexture tempMap, RenderTexture blurMap, RenderTexture overlayBlurMap)
        {
            blitShader.ImageSize = new Vector4(imageSizeX, imageSizeY, 0, 0);
            blitShader.BlurContrast = 1.0f;
            blitShader.BlurSpread = 1.0f;

            // Blur the image 1
            blitShader.BlurSamples = Settings.BlurSize;
            blitShader.BlurDirection = new Vector4(1, 0, 0, 0);

            /*if (Settings.UseAdjustedDiffuse)
            {
                if (Settings.BlurSize == 0)
                    Graphics.Blit(_diffuseMap, _tempMap);
                else
                    Graphics.Blit(_diffuseMap, _tempMap, _blitMaterial, 1);
            }
            else*/
            {
                if (Settings.BlurSize == 0)
                    Graphics.Blit(diffuseTexture, tempMap);
                else
                    Graphics.Blit(diffuseTexture, tempMap, blitShader.Material, 1);
            }

            blitShader.BlurDirection = new Vector4(0, 1, 0, 0);

            if (Settings.BlurSize == 0)
                Graphics.Blit(tempMap, blurMap);
            else
                Graphics.Blit(tempMap, blurMap, blitShader.Material, 1);

            //ThisMaterial.SetTexture("_BlurTex", _blurMap);

            // Blur the image for overlay
            blitShader.BlurSamples = Settings.OverlayBlurSize;
            blitShader.BlurDirection = new Vector4(1, 0, 0, 0);

            //Graphics.Blit(Settings.UseAdjustedDiffuse ? _diffuseMap : _diffuseMapOriginal, tempMap, blitShader.Material, 1);
            Graphics.Blit(diffuseTexture, tempMap, blitShader.Material, 1);

            blitShader.BlurDirection = new Vector4(0, 1, 0, 0);
            Graphics.Blit(tempMap, overlayBlurMap, blitShader.Material, 1);

            //ThisMaterial.SetTexture("_OverlayBlurTex", _overlayBlurMap);
        }

        public Texture2D CreateMetalicMap(in Texture2D diffuseTexture, RenderTexture tempMap, RenderTexture blurMap, RenderTexture overlayBlurMap)
        {
            var metalicShader = new BlitMetallicShaderWrapper();

            //metalicShader.ImageSize = new Vector4(imageSizeX, imageSizeY, 0, 0);

            metalicShader.MetalColor = Settings.MetalColor;
            metalicShader.SampleUV = new Vector4(Settings.SampleUv.x, Settings.SampleUv.y, 0, 0);

            metalicShader.HueWeight = Settings.HueWeight;
            metalicShader.SatWeight = Settings.SatWeight;
            metalicShader.LumWeight = Settings.LumWeight;

            metalicShader.MaskLow = Settings.MaskLow;
            metalicShader.MaskHigh = Settings.MaskHigh;

            //metalicShader.Slider = _slider;

            metalicShader.BlurOverlay = Settings.BlurOverlay;

            metalicShader.FinalContrast = Settings.FinalContrast;

            metalicShader.FinalBias = Settings.FinalBias;

            metalicShader.BlurTex = blurMap;

            metalicShader.OverlayBlurTex = overlayBlurMap;


            //Graphics.Blit(Settings.UseAdjustedDiffuse ? _diffuseMap : _diffuseMapOriginal, _tempMap, _metallicBlitMaterial, 0);
            Graphics.Blit(diffuseTexture, tempMap, metalicShader.Material, 0);


            var metallicMap = new Texture2D(tempMap.width, tempMap.height, TextureFormat.ARGB32, true, true);
            metallicMap.ReadPixels(new Rect(0, 0, tempMap.width, tempMap.height), 0, 0);
            metallicMap.Apply();

            return metallicMap;
        }
    }
}
